export interface Project {
name: string;
projectCreationDate: Date;
lastBuildDate: Date;

} 
 
