import { Component, OnInit, Input, } from '@angular/core';
@Component({
  selector: 'app-inputdata',
  templateUrl: './inputdata.component.html',
  styleUrls: ['./inputdata.component.css']
})
export class InputdataComponent implements OnInit {

 // @Input() productData = { :'', prod_desc: '', prod_price: 0 };

  constructor() { }

  ngOnInit() {
  }

}
