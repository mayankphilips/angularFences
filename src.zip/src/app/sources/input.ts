export class Input{
    link :string;
    branch: string;
    settings: string;
}