export class RawCodeSelection {

    constructor(
        public rawCode : string,
        public toolSelected : string
    ){}
}
