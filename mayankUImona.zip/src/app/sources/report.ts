export interface Report{
    errorsThen : string;
    errorsNow: string;
    percentageChange: string;
}