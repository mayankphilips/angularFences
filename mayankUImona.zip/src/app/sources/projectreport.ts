import { Report } from './report';

export interface ProjectReport{
    status: string;
    report: any;
}