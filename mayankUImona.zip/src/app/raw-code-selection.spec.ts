import { RawCodeSelection } from './raw-code-selection';

describe('RawCodeSelection', () => {
  it('should create an instance', () => {
    expect(new RawCodeSelection()).toBeTruthy();
  });
});
