import { Component } from '@angular/core';

@Component({
  selector: 'app-fences-home',
  templateUrl: './fences-home.component.html',
  styleUrls: ['./fences-home.component.css']
})
export class FencesHomeComponent {


  

}
