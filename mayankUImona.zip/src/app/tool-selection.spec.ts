import { ToolSelection } from './tool-selection';

describe('ToolSelection', () => {
  it('should create an instance', () => {
    expect(new ToolSelection()).toBeTruthy();
  });
});
