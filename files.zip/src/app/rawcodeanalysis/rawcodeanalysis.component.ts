import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rawcodeanalysis',
  templateUrl: './rawcodeanalysis.component.html',
  styleUrls: ['./rawcodeanalysis.component.css']
})
export class RawcodeanalysisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
