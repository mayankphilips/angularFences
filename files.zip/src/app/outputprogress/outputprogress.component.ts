import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outputprogress',
  templateUrl: './outputprogress.component.html',
  styleUrls: ['./outputprogress.component.css']
})
export class OutputprogressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
