import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inputdata',
  templateUrl: './inputdata.component.html',
  styleUrls: ['./inputdata.component.css']
})
export class InputdataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
